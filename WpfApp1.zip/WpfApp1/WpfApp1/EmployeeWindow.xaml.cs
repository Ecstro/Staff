﻿using System.Collections.ObjectModel;
using System.Windows;

namespace WpfApp
{
    public partial class EmployeeWindow : Window
    {
        public ObservableCollection<Employee> Employees { get; set; }

        public EmployeeWindow()
        {
            InitializeComponent();
            Employees = new ObservableCollection<Employee>();
            EmployeeDataGrid.ItemsSource = Employees;
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            string employeeName = Microsoft.VisualBasic.Interaction.InputBox("Введите имя сотрудника:", "Добавить сотрудника", "");
            if (!string.IsNullOrWhiteSpace(employeeName))
            {
                Employees.Add(new Employee { Name = employeeName });
            }
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            if (EmployeeDataGrid.SelectedItem is Employee selectedEmployee)
            {
                Employees.Remove(selectedEmployee);
            }
            else
            {
                MessageBox.Show("Выберите сотрудника для удаления.");
            }
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            if (EmployeeDataGrid.SelectedItem is Employee selectedEmployee)
            {
                string newName = Microsoft.VisualBasic.Interaction.InputBox("Введите новое имя:", "Редактировать сотрудника", selectedEmployee.Name);
                if (!string.IsNullOrWhiteSpace(newName))
                {
                    selectedEmployee.Name = newName;
                    EmployeeDataGrid.Items.Refresh();
                }
            }
            else
            {
                MessageBox.Show("Выберите сотрудника для редактирования.");
            }
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close(); // Закрываем текущее окно
        }
    }

    public class Employee
    {
        public string Name { get; set; }
    }
}
